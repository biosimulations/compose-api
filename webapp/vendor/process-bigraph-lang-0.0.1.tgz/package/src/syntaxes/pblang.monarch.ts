// Monarch syntax highlighting for the pblang language.
export default {
    keywords: [
        'adapter','array','as','at','bridge','choices','compartments','composite','config','emit','every','extra','false','file','from','import','inputs','interface','link','meta','model','module','node','null','options','outputs','param','parameters','ports','priority','process','schema','shared','species','step','store','time','true','with'
    ],
    operators: [
        '*',',','->','.','..','...','/',':',';','<','=','>','?','@','|'
    ],
    symbols: /\(|\)|\*|,|->|\.|\.\.|\.\.\.|\/|:|;|<|=|>|\?|@|\[|\]|\{|\||\}/,

    tokenizer: {
        initial: [
            { regex: /\/\/\/[^\n\r]*/, action: {"token":"DOC"} },
            { regex: /[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*\.\{/, action: {"token":"IMPORT_PATH"} },
            { regex: /\$\{[A-Za-z_][A-Za-z0-9_]*\}/, action: {"token":"PARAM"} },
            { regex: /-?([0-9]+\.[0-9]*|\.[0-9]+)([eE][+-]?[0-9]+)?|-?[0-9]+[eE][+-]?[0-9]+/, action: {"token":"number"} },
            { regex: /-?[0-9]+/, action: {"token":"number"} },
            { regex: /[_a-zA-Z][\w_]*/, action: { cases: { '@keywords': {"token":"keyword"}, '@default': {"token":"ID"} }} },
            { regex: /"(\\.|[^"\\])*"/, action: {"token":"string"} },
            { include: '@whitespace' },
            { regex: /@symbols/, action: { cases: { '@operators': {"token":"operator"}, '@default': {"token":""} }} },
        ],
        whitespace: [
            { regex: /\s+/, action: {"token":"white"} },
            { regex: /\/\/[^\n\r]*/, action: {"token":"comment"} },
            { regex: /\/\*/, action: {"token":"comment","next":"@comment"} },
        ],
        comment: [
            { regex: /[^/\*]+/, action: {"token":"comment"} },
            { regex: /\*\//, action: {"token":"comment","next":"@pop"} },
            { regex: /[/\*]/, action: {"token":"comment"} },
        ],
    }
};
