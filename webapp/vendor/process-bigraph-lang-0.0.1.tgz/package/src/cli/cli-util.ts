import type { AstNode, LangiumCoreServices, LangiumDocument } from "langium";
import chalk from "chalk";
import * as path from "node:path";
import * as fs from "node:fs";
import { URI } from "langium";

/**
 * Load, build and validate a file. With `lenient`, only lexer and parser errors abort: semantic findings (the v2
 * checker's) are left for the caller, so a document with mistakes can still be dumped as an AST and checked.
 */
export async function extractDocument(
  fileName: string,
  services: LangiumCoreServices,
  lenient = false,
): Promise<LangiumDocument> {
  const extensions = services.LanguageMetaData.fileExtensions;
  if (!extensions.includes(path.extname(fileName))) {
    console.error(
      chalk.yellow(
        `Please choose a file with one of these extensions: ${extensions}.`,
      ),
    );
    process.exit(1);
  }

  if (!fs.existsSync(fileName)) {
    console.error(chalk.red(`File ${fileName} does not exist.`));
    process.exit(1);
  }

  const document =
    await services.shared.workspace.LangiumDocuments.getOrCreateDocument(
      URI.file(path.resolve(fileName)),
    );
  await services.shared.workspace.DocumentBuilder.build([document], {
    validation: true,
  });

  const parseErrors =
    document.parseResult.lexerErrors.length +
    document.parseResult.parserErrors.length;
  const validationErrors = (document.diagnostics ?? []).filter(
    (e) => e.severity === 1 && (!lenient || parseErrors > 0),
  );
  if (validationErrors.length > 0) {
    console.error(chalk.red("There are validation errors:"));
    for (const validationError of validationErrors) {
      console.error(
        chalk.red(
          `line ${validationError.range.start.line + 1}: ${
            validationError.message
          } [${document.textDocument.getText(validationError.range)}]`,
        ),
      );
    }
    process.exit(1);
  }

  return document;
}

export async function extractAstNode<T extends AstNode>(
  fileName: string,
  services: LangiumCoreServices,
  lenient = false,
): Promise<T> {
  return (await extractDocument(fileName, services, lenient)).parseResult
    ?.value as T;
}

interface FilePathData {
  destination: string;
  name: string;
}

export function extractDestinationAndName(
  filePath: string,
  destination: string | undefined,
): FilePathData {
  filePath = path
    .basename(filePath, path.extname(filePath))
    .replace(/[.-]/g, "");
  return {
    destination: destination ?? path.join(path.dirname(filePath), "generated"),
    name: path.basename(filePath),
  };
}
